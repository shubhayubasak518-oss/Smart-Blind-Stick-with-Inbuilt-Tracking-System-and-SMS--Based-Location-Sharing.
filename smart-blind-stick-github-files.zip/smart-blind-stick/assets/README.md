# Project Assets

Add your own prototype photos, wiring diagram, enclosure images, and demo screenshots here.

Recommended filenames:
- `prototype-front.jpg`
- `prototype-wiring.jpg`
- `serial-monitor.png`
- `sms-location-demo.png`

Only add images you have permission to publish. Blur phone numbers, personal addresses, and other private information before committing screenshots.
