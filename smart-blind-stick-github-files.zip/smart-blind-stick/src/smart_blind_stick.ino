/*
  Smart Blind Stick with GPS Tracking and SMS-Based Location Sharing
  Starter example for Arduino Uno + HC-SR04 + NEO-6M + SIM800L.

  IMPORTANT:
  - Verify pins, baud rates, voltage levels, and power requirements for your modules.
  - SIM800L needs a suitable supply with sufficient burst-current capability.
  - Test modules individually before integrated use.
  - This sample is a starting point, not certified safety equipment.
*/

#include <SoftwareSerial.h>
#include <TinyGPSPlus.h>

// Illustrative pin assignments; change to match your wiring.
const uint8_t TRIG_PIN = 6;
const uint8_t ECHO_PIN = 7;
const uint8_t BUZZER_PIN = 5;
const uint8_t EMERGENCY_BUTTON_PIN = 4;

// SoftwareSerial constructor order is RX, TX from Arduino's perspective.
SoftwareSerial gpsSerial(8, 9);  // Arduino RX <- GPS TX, Arduino TX -> GPS RX
SoftwareSerial gsmSerial(10, 11); // Arduino RX <- GSM TX, Arduino TX -> GSM RX

TinyGPSPlus gps;

const unsigned long GPS_BAUD = 9600; // Confirm your GPS module's configured baud rate.
const unsigned long GSM_BAUD = 9600; // Confirm your GSM module's configured baud rate.
const float OBSTACLE_THRESHOLD_CM = 80.0;
const unsigned long SMS_COOLDOWN_MS = 15000;

// Replace with your emergency contact number, including country code.
// Example format only: "+91XXXXXXXXXX"
const char EMERGENCY_PHONE[] = "+91XXXXXXXXXX";

bool previousButtonState = HIGH;
unsigned long lastSmsTime = 0;

float readDistanceCm() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(3);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  // Timeout prevents waiting indefinitely; 30 ms is roughly a 5 m round trip.
  unsigned long duration = pulseIn(ECHO_PIN, HIGH, 30000UL);
  if (duration == 0) {
    return -1.0; // No echo / out of range.
  }

  return (duration * 0.0343f) / 2.0f;
}

void updateGpsFor(unsigned long durationMs) {
  unsigned long start = millis();
  gpsSerial.listen();

  while (millis() - start < durationMs) {
    while (gpsSerial.available()) {
      gps.encode(gpsSerial.read());
    }
  }
}

bool sendSms(const char *message) {
  gsmSerial.listen();

  // Basic AT-command sequence. For a robust product, parse modem responses,
  // check network registration, handle errors, and implement retries.
  gsmSerial.println(F("AT"));
  delay(500);
  gsmSerial.println(F("AT+CMGF=1")); // SMS text mode
  delay(500);
  gsmSerial.print(F("AT+CMGS=\""));
  gsmSerial.print(EMERGENCY_PHONE);
  gsmSerial.println(F("\""));
  delay(800);
  gsmSerial.print(message);
  gsmSerial.write(26); // Ctrl+Z submits the SMS
  delay(5000);

  // This starter function does not parse the modem's final response.
  return true;
}

void sendEmergencySms() {
  if (millis() - lastSmsTime < SMS_COOLDOWN_MS) {
    Serial.println(F("SMS cooldown active; not sending another message."));
    return;
  }

  // Give the GPS receiver a brief window to provide fresh data.
  updateGpsFor(1500);

  char message[180];

  if (gps.location.isValid() && gps.location.age() < 15000UL) {
    double latitude = gps.location.lat();
    double longitude = gps.location.lng();

    snprintf(message, sizeof(message),
             "Emergency alert: I may need assistance. Location: "
             "https://maps.google.com/?q=%.6f,%.6f",
             latitude, longitude);
  } else {
    snprintf(message, sizeof(message),
             "Emergency alert: I may need assistance. GPS location is currently unavailable.");
  }

  Serial.print(F("Sending SMS: "));
  Serial.println(message);

  if (sendSms(message)) {
    lastSmsTime = millis();
  }
}

void setup() {
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(EMERGENCY_BUTTON_PIN, INPUT_PULLUP);

  Serial.begin(9600);
  gpsSerial.begin(GPS_BAUD);
  gsmSerial.begin(GSM_BAUD);

  Serial.println(F("Smart Blind Stick starter firmware"));
  Serial.println(F("Check module power, wiring, baud rates, and contact number."));
}

void loop() {
  // Keep feeding GPS data during normal operation.
  gpsSerial.listen();
  while (gpsSerial.available()) {
    gps.encode(gpsSerial.read());
  }

  float distanceCm = readDistanceCm();

  if (distanceCm > 0 && distanceCm <= OBSTACLE_THRESHOLD_CM) {
    digitalWrite(BUZZER_PIN, HIGH);
  } else {
    digitalWrite(BUZZER_PIN, LOW);
  }

  if (distanceCm > 0) {
    Serial.print(F("Distance: "));
    Serial.print(distanceCm);
    Serial.println(F(" cm"));
  } else {
    Serial.println(F("Distance: no echo"));
  }

  bool currentButtonState = digitalRead(EMERGENCY_BUTTON_PIN);

  // Detect button press edge (INPUT_PULLUP: LOW means pressed).
  if (previousButtonState == HIGH && currentButtonState == LOW) {
    sendEmergencySms();
  }
  previousButtonState = currentButtonState;

  delay(60);
}
