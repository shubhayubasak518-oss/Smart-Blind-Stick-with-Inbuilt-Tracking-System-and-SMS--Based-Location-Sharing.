# System Block Diagram

```text
       +------------------+
       | HC-SR04 Sensor   |
       +--------+---------+
                |
                v
       +------------------+        +----------------+
       | Arduino Uno      |------->| Buzzer         |
       | Main Controller  |        +----------------+
       +---+----------+---+
           |          |
       GPS UART    GSM UART
           |          |
           v          v
    +-------------+  +-------------+
    | NEO-6M GPS  |  | SIM800L GSM |
    +-------------+  +------+------+
                            |
                            v
                    SMS with map link
                            |
                            v
                    Emergency contact

       Emergency push button ---> Arduino input
```

This is a conceptual diagram. Update it to match the exact board, interfaces, and hardware actually used in your build.
