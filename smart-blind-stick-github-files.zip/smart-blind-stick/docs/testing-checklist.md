# Testing Checklist

Record the date, setup, expected result, actual result, and pass/fail status for every test.

| Test | Expected result | Actual result / notes | Status |
|---|---|---|---|
| HC-SR04 at 20–80 cm | Distance is reasonably close to a ruler measurement | Fill in | Not tested |
| Object inside threshold | Buzzer turns on | Fill in | Not tested |
| Object outside threshold | Buzzer turns off | Fill in | Not tested |
| GPS outdoors | Valid coordinates are acquired | Fill in | Not tested |
| GPS without fix | Firmware reports location unavailable | Fill in | Not tested |
| GSM network registration | Modem can register on cellular network | Fill in | Not tested |
| Emergency button | SMS attempt is triggered once per press | Fill in | Not tested |
| SMS with GPS fix | Message contains a Google Maps link | Fill in | Not tested |
| SMS without GPS fix | Message clearly states location is unavailable | Fill in | Not tested |
| Power stability | Board and modules remain stable during GSM transmit bursts | Fill in | Not tested |

Do not mark tests as passed until you have performed them on the actual hardware.
