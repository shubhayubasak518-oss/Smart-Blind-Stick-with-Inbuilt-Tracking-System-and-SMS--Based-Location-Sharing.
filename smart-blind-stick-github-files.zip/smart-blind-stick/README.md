# Smart Blind Stick with GPS Tracking and SMS-Based Location Sharing

An assistive embedded-systems project designed to help visually impaired users detect nearby obstacles and share their location with a trusted contact during an emergency.

> **Important:** This repository is a starter template. Update the board, wiring, pin assignments, and features to match your actual build before publishing. The sample firmware assumes an Arduino Uno, HC-SR04, NEO-6M GPS, and SIM800L GSM module. Hardware behavior has not been verified on a physical prototype.

## Features

- Ultrasonic obstacle detection
- Buzzer and optional vibration-motor alerts
- GPS coordinate acquisition
- Emergency button to request an SMS
- SMS containing a Google Maps link
- Modular, commented Arduino firmware

## System overview

1. The HC-SR04 measures the distance to an object.
2. The Arduino alerts the user when an object is closer than the configured threshold.
3. The NEO-6M GPS module provides latitude and longitude when a valid fix is available.
4. When the emergency button is pressed, the SIM800L sends an SMS to the configured contact number.
5. The message includes a Google Maps link if a valid GPS fix is available; otherwise, it reports that the location is unavailable.

## Hardware

| Component | Purpose |
|---|---|
| Arduino Uno | Main controller |
| HC-SR04 | Obstacle-distance measurement |
| NEO-6M GPS | Location coordinates |
| SIM800L GSM | SMS delivery |
| Buzzer | Audible warning |
| Optional vibration motor + driver | Tactile warning |
| Push button | Emergency SMS trigger |
| Suitable regulated power supplies | Power for controller and modules |

**Power note:** The SIM800L requires a suitable supply capable of handling its burst current and must not be powered directly from the Arduino 5 V pin. Check the exact module's voltage requirements and use a common ground. Do not connect a vibration motor directly to a GPIO; use an appropriate transistor/MOSFET driver and protection components.

## Software

- Embedded C/C++
- Arduino IDE
- TinyGPS++ library
- SoftwareSerial (included with many Arduino AVR board packages)

## Example wiring

The following pins are illustrative and must be checked against your hardware and library limitations.

| Module signal | Arduino Uno pin |
|---|---|
| HC-SR04 TRIG | D6 |
| HC-SR04 ECHO | D7 |
| Buzzer signal | D5 |
| Emergency button | D4 to GND (uses `INPUT_PULLUP`) |
| GPS TX | D8 (Arduino GPS RX) |
| GPS RX | D9 (Arduino GPS TX, through suitable level shifting if required) |
| GSM TX | D10 (Arduino GSM RX) |
| GSM RX | D11 (Arduino GSM TX, through suitable level shifting if required) |

Use voltage-level conversion where needed. Check the GPS and GSM module documentation before wiring. SoftwareSerial performance and simultaneous serial reception can be limited on an Uno.

## Setup

1. Install the Arduino IDE.
2. Install **TinyGPSPlus** from the Arduino Library Manager.
3. Open `src/smart_blind_stick.ino`.
4. Set `EMERGENCY_PHONE` to a number in international format supported by your SIM/network.
5. Confirm all pin assignments and module baud rates for your exact modules.
6. Upload the sketch and open Serial Monitor at 9600 baud.
7. Test each module independently before integrated testing.

## Testing checklist

- [ ] Ultrasonic distance readings are plausible.
- [ ] Buzzer activates below the configured distance threshold.
- [ ] GPS reports a valid fix outdoors.
- [ ] GSM module registers on the network and can send a test SMS.
- [ ] Emergency button triggers only one SMS per press.
- [ ] SMS link opens at the expected coordinates.
- [ ] Behavior is safe when GPS has no fix or GSM service is unavailable.
- [ ] Battery runtime and enclosure are tested.

## Limitations and safety

This is a student assistive-technology prototype, not a certified mobility aid. It does not replace a white cane, orientation-and-mobility training, or other established mobility tools. Ultrasonic sensors can miss some surfaces, drop-offs, thin objects, and hazards outside their field of view. GPS may be inaccurate or unavailable indoors. SMS delivery depends on cellular coverage, SIM status, and network availability. Test with a trusted contact and do not rely on this prototype as the sole emergency system.

## Repository structure

```text
smart-blind-stick/
├── README.md
├── LICENSE
├── .gitignore
├── docs/
│   ├── block-diagram.md
│   └── testing-checklist.md
├── assets/
│   └── README.md
└── src/
    └── smart_blind_stick.ino
```

## Future improvements

- Add low-battery monitoring and low-battery warnings.
- Add robust GPS/GSM status indicators and retry handling.
- Use a dedicated hardware UART or a controller with multiple UARTs.
- Add enclosure, wiring, and prototype photographs.
- Add measured test results, power budget, and known limitations.
- Consider additional sensing only after evaluating reliability and user safety.

## Author

Add your name, institution, and contact details here if you want them public.
